#include <iostream>
#include "Astar_HR.h"

using namespace std;

Astar_HR::Astar_HR(int xs, int ys, int xg, int yg, int xMax, int yMax, int grid[300][200]) {
    this->xs = xs;
    this->ys = ys;
    this->xg = xg;
    this->yg = yg;
    this->xMax = xMax;
    this->yMax = yMax;
    for (int i = 0; i < xMax; ++i) {
        for (int j = 0; j < yMax; ++j) {
            this->grid[i][j] = grid[i][j];
        }
    }
}

double Astar_HR::heuristic(int xn, int yn, int xg, int yg) {
    //return abs(xn - xg) + abs(yn - yg);
    double r = sqrt(pow(xg - xn, 2) + pow(yg - yn, 2));
    return r;
}

void Astar_HR::expandNode(Node* dad) {
    Node son(0, 0, 0, 0, nullptr);
    int x = 0, y = 0;

    // Checking the points that are 1 move from the current point. 8 points in total
    // Starting from the top left and ending in the bottom right, moving left to right
    for (int i = -1; i <= 1; i++) {
        x = dad->getX() + i;
        //cout << "X=" << x << endl;
        if (x >= 0 && x <= xMax) {
            for (int j = -1; j <= 1; j++) {
                y = dad->getY() + j;
                //cout << "Y=" << y << endl;
                if (i != 0 || j != 0) {
                    //cout << "IN" << endl;
                    if (y >= 0 && y <= yMax) {
                        //cout << "X=" << x << "Y=" << y << endl;
                        /*if () {

                        }*/
                        son.setParameters(x, y, dad->getMoveCost() + 1, heuristic(x, y, this->xg, this->yg), dad);
                        //son.printNode();
                        pq.push(son);
                    }
                }
                y = y - j;
            }
        }
        x = x - i;
    }

}


int Astar_HR::setPath(int*& x, int*& y, Node* n) {
    int len = 0;



    do {
        //cout << n->getParent() << endl;
        path.push(n);
        n = n->getParent();
        len++;

    } while (n->getParent() != nullptr);

    // Allocate new memory for x and y
    x = new int[len];
    y = new int[len];

    if (x == nullptr || y == nullptr) {
        cout << "Memory allocation failed!" << endl;
        exit(1);
    }


    for (int i = 0; i < len; i++) {
        n = path.top();
        path.pop();

        x[i] = n->getX();
        y[i] = n->getY();

        //cout << "x=" << (**x)[i] << " ,  y=" << (**y)[i] << endl;

    }
    return len;
}

int Astar_HR::pathGeneration(int*& x, int*& y) {
    Node* n = new Node(xs, ys, 0, heuristic(xs, ys, xg, yg), nullptr);
    int len;


    while (true) {

        //cout << "----------" << endl;
        //n->printNode();
        //cout << "----------" << endl;

        if (n->getX() == xg && n->getY() == yg) {
            break;
        }

        expandNode(n);

        n = new Node(pq.top());
        pq.pop();

    }


    //printPath();
    len = setPath(x, y, n);

    /*for (int i = 0; i < len; i++) {
        cout << "x=" << (*x)[i] << " , y=" << (*y)[i] << endl;
    }*/

    return len;
}