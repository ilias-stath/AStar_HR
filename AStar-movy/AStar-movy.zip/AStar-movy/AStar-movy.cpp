#include <iostream>
#include "AStar_HR.h"

using namespace std;


int main()
{
    int* xPoints = nullptr;
    int* yPoints = nullptr;
    int len = 0;
    int xMax = 300, yMax = 200;
    int grid[300][200];

    for (int x = 0; x < xMax; x++) {
        for (int y = 0; y < yMax; y++) {
            grid[x][y] = 0;
        }
    }

    /*for (int x = 0; x < xMax; x++) {
        for (int y = 0; y < yMax; y++) {
            cout << grid[x][y];
        }
        cout << endl;
    }*/

    Astar_HR shit(5, 5, 15, 10, xMax, yMax, grid);
    len = shit.pathGeneration(xPoints, yPoints);

    cout << len << endl;
    for (int i = 0; i < len; i++) {
        cout << "x=" << xPoints[i] << " ,  y=" << yPoints[i] << endl;
    }

}